<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHPWebPage.php to edit this template
-->
<html>
    <head>
        <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<style>
        .fa {  
  color: red;
}  
.nav-link{
    color: #b518a3;
}
.az{
            background-color: black;
            color: white;
        }
         .first{
            margin-bottom: -1px;
            background: 0 0;
            border-top-left-radius: 0.25rem;
            border-top-right-radius: 0.25rem;
            text-decoration: none;
            width: 20px;
            height: 30px;
            display: flex;
            flex-wrap: wrap;
            align-content: center;
            
        }
    .click:hover{
        color: green;
    }
        </style>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Rescue</title>
    
    </head>
    <body>
        <div class="container-fluid" style="background-color: #4aed05;">
         <div class="row nav nav-tabs" style="color: #f2440a;font-size: 20px; font-weight: bold;" id="qwe" '>
                <div class="col-sm-1">
                    <img src="logo/logo_7.0.jpg" height="65px" width="65px">
                </div>
             <div class="col-sm-6" style="font-size: 40px; font-weight: bold; color: #fa1d05;" >
                   SAMRAS BHARAT SEVA SANSTHAN
                </div>
                <div class="col-sm-1 nav-item">
                    <a class="first click" href="HOME.php">&nbsp; HOME</a>
                </div><!-- comment --> 
                <div class="col-sm-1 nav-item dropdown">
                     <a class="first click"  href="Work.php" >&nbsp; WORK</a>
                </div><!-- comment -->
                <div class="col-sm-1 nav-item">
                    <a class="first click" href="Report-issue.php">&nbsp; REPORT</a>
                </div><!-- comment -->
                <div class="col-sm-1 nav-item">
                    <a class="first click" href="Contact-us.php">&nbsp; CONTACT</a>
                </div>
                <div class="col-sm-1 nav-item">
                   <a class="first click" href="FAQ.php">&nbsp;&nbsp;&nbsp;<BR>About us</a>
                </div><!-- comment -->
            </div>
        </div>       
        <h1 style="text-align:center;"> <i><u> RESCUE</u></i></h1><br>
         <div class="container-fluid" align="center">
         <div class="row nav nav-tabs">
             <div class="col-sm-1"></div>
             <div class="col-sm-10" style="font-size:24px">
SAMRAS BHARAT’s rescue process is thoroughly researched with intensive and 
extensive preparation. It is conducted in accordance with legal requirements as
part of collective action with specific government agencies. The process often
involves physical risks to SAMRAS BHARAT activists. There have been cases where
the activists have been subjected to violent attacks while trying to rescue children.
However, they have continued undeterred in their commitment towards the protection of children.<br><br>
             </div>
             <div class="col-sm-1"></div>
         </div></div><!-- comment -->
             
    <div class="container-fluid" align="center">
         <div class="row nav nav-tabs" style="color: #1c2a94;" id="qwe" '>
             <div class="col-sm-1"></div>
             <div class="col-sm-10">
                 <marquee direction="right" 
        behavior="alternate" 
        >
    <img src="rescue1/2.jpeg" width="450px" height="300px" alt="alt"/>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <img src="rescue1/3.jpeg" width="450px" height="300px" alt="alt"/>
        
    </marquee>
             </div>
                 <div class="col-sm-1"></div>
             </div><!-- comment -->
         </div>
    </div><br>
<h3> </h3>
<h3 style="text-align:center;"> <i><u> Identification:</u></i></h3><br>
         <div class="container-fluid" align="center">
         <div class="row nav nav-tabs">
             <div class="col-sm-1"></div>
             <div class="col-sm-10" style="font-size:24px">
Identifications are done by SAMRAS BHARAT’s intelligence network
on the ground and information regarding child rights violations is
also gathered through complaints received from individuals, parents,
victims, partner NGOs and informer networks. The team gathers information
about the demographics of the community, industry, the approximate number
of child labourers and the type of work they are engaged, along with other
details to do a risk analysis. Upon successful verification of the information
gathered from various sources, complaints are filed with the concerned Law Enforcement 
Agencies (LEAs) to initiate action. Law Enforcement Agencies includes Human Trafficking 
Unit and Police Staff.<br><br>
             </div>
             <div class="col-sm-1"></div><!-- comment -->
         </div></div><br>
             
 <div class="container-fluid" align="center">
         <div class="row nav nav-tabs" style="color: #1c2a94;" id="qwe" '>
             <div class="col-sm-1"></div>
             <div class="col-sm-10">
                 <marquee direction="right" 
        behavior="alternate" 
        >
    <img src="rescue1/4.jpeg" width="450px" height="300px" alt="alt"/>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <img src="rescue1/5.jpeg" width="450px" height="300px" alt="alt"/>
        
    </marquee>
             </div>
                 <div class="col-sm-1"></div>
             </div><!-- comment -->
         </div>
    </div>
    <br>
    <h3 style="text-align:center;"> <i><u>Process: </u></i></h3><br>
         <div class="container-fluid" align="center">
         <div class="row nav nav-tabs">
             <div class="col-sm-1"></div>
             <div class="col-sm-10" style="font-size:24px">
Based on the complaints filed, SAMRAS BHARAT along with LEAs plans for a rescue 
operation and conducts a raid on the identified localities/establishments. Support
and partnership with local administration are sought before the operation, which is
an important aspect of this intervention, to avoid any violation of the law.
Thereafter, the identified victims are removed in a raid led by the District 
Magistrate and other government authorities. SAMRAS BHARAT ensures that at this 
stage the children are safely extradited from the site and are placed in a safe 
environment (Child Care Institution) as per the orders of Child Welfare Committee
(CWC), a statutory body. During the rescue, LEAs also initiate actions against errant
traffickers/employers for sanction of economic recovery and take other punitive measures
as per the law to deter the exploitation of children.<br><br>
             </div>
             <div class="col-sm-1"></div><!-- comment -->
         </div></div>
 <br>
 <div class="container-fluid" align="center">
         <div class="row nav nav-tabs" style="color: #1c2a94;" id="qwe" '>
             <div class="col-sm-1"></div>
             <div class="col-sm-10">
                 <marquee direction="right" 
        behavior="alternate" 
        >
    <img src="rescue1/6.jpeg" width="450px" height="300px" alt="alt"/>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <img src="rescue1/1.jpeg" width="350px" height="450px" alt="alt"/>
        
    </marquee><br><br>
             </div>
                 <div class="col-sm-1"></div>
             </div><!-- comment -->
         </div>
    </div>
     <div class="container-fluid" align="center">
         <div class="row nav nav-tabs">
             <div class="col-sm-1"></div>
             <div class="col-sm-10" style="font-size:24px">
    Post rescue, the children are placed under Child Care Institutions (CCI)
    on the order of the CWC wherein their safety and protection is ensured. Children
    are sent to or CCIs run by the government and other NGOs for short-term rehabilitation.
    <br><!-- comment -->
    <br>
    In order to create legal and economic deterrence, Samras Bharat ensures that each
    child’s case is represented in the court and trials are initiated in the court against
    the employers/traffickers. One of the first step towards ensuring prosecution is
    registration of First Information Report (FIR) against the employers/traffickers
    under the relevant sections of the law and time-bound filing of charge sheets.
    Samras Bharat's legal team supports the children and family during the period of
    trial while also ensuring their recovery of back wages and other statutory compensations.<br><!-- comment -->
    <br>
    Samras Bharat believes that rescue is only half the work done. It is important
    to ensure that the children remain safe and healthy, recover from the trauma
    they have experienced, go to school and stay protected from child labour after
    they go back home.
    </div>
             <div class="col-sm-1"></div><!-- comment -->
         </div></div>
 <br>
         <div align="center" class="az">
            <br><h3>Created by XVL</h3>
            <h4>Copyright &COPY; All Rights Reserved</h4>
        </div>
        <?php
        // put your code here
        ?>
    </body>
</html>
