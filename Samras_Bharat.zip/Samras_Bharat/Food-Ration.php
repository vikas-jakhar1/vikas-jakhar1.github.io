<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHPWebPage.php to edit this template
-->
<html>
    <head>
        <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<style>
        .fa {  
  color: red;
}  
.nav-link{
    color: #b518a3;
}
.az{
            background-color: black;
            color: white;
        }
         .first{
            margin-bottom: -1px;
            background: 0 0;
            border-top-left-radius: 0.25rem;
            border-top-right-radius: 0.25rem;
            text-decoration: none;
            width: 20px;
            height: 30px;
            display: flex;
            flex-wrap: wrap;
            align-content: center;
            
        }
    .click:hover{
        color: green;
    }
        </style>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Rescue</title>
    
    </head>
    <body>
        <div class="container-fluid" style="background-color: #4aed05;">
         <div class="row nav nav-tabs" style="color: #f2440a;font-size: 20px; font-weight: bold;" id="qwe" '>
                <div class="col-sm-1">
                    <img src="logo/logo_7.0.jpg" height="65px" width="65px">
                </div>
             <div class="col-sm-6" style="font-size: 40px; font-weight: bold; color: #fa1d05;" >
                   SAMRAS BHARAT SEVA SANSTHAN
                </div>
                <div class="col-sm-1 nav-item">
                    <a class="first click" href="HOME.php">&nbsp; HOME</a>
                </div><!-- comment --> 
                <div class="col-sm-1 nav-item dropdown">
                     <a class="first click"  href="Work.php" >&nbsp; WORK</a>
                </div><!-- comment -->
                <div class="col-sm-1 nav-item">
                    <a class="first click" href="Report-issue.php">&nbsp; REPORT</a>
                </div><!-- comment -->
                <div class="col-sm-1 nav-item">
                    <a class="first click" href="Contact-us.php">&nbsp; CONTACT</a>
                </div>
                <div class="col-sm-1 nav-item">
                    <a class="first click" href="FAQ.php">&nbsp;&nbsp;&nbsp;<BR>About us</a>
                </div><!-- comment -->
            </div>
        </div>       
        <h1 style="text-align:center;"> <i><u>Providing Food and Ration</u></i></h1><br>
         <div class="container-fluid" align="center">
         <div class="row nav nav-tabs">
             <div class="col-sm-1"></div>
             <div class="col-sm-10" style="font-size:24px">
During COVID, the main problem occured was of food. People were dying
due covid but also from hunger. Mostly people affected by hunger were
people who were working as daily wages on construction sites etc were
closed due to lockdown.<br><br>
Samras Bharat started providing food and ration to people in need
during the pandemic. As there was lockdown in place all over the
country People like them were not able to migrate to there hometowns
or eat there fill as they get daily wages and buy daily rations and food.<br><br><!-- comment -->
We started providing them first by collecting ration like rice and
pulses from the societies and colonies and give them as packet.
Then we also provided them food packets and rations packets to there need.<br><br>
             </div>
             <div class="col-sm-1"></div>
         </div></div><!-- comment -->
             
    <div class="container-fluid" align="center">
         <div class="row nav nav-tabs" style="color: #1c2a94;" id="qwe" '>
             <div class="col-sm-1"></div>
             <div class="col-sm-10">
                 <marquee direction="right" 
        behavior="alternate" 
        >
    <img src="rescue1/2.jpeg" width="450px" height="300px" alt="alt"/>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <img src="rescue1/3.jpeg" width="450px" height="300px" alt="alt"/>
        
    </marquee>
             </div>
                 <div class="col-sm-1"></div>
             </div><!-- comment -->
         </div>
    </div><br>
<h3> </h3>

 <br>
         <div align="center" class="az">
            <br><h3>Created by XVL</h3>
            <h4>Copyright &COPY; All Rights Reserved</h4>
        </div>
        <?php
        // put your code here
        ?>
    </body>
</html>
