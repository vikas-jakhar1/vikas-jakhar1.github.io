<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHPWebPage.php to edit this template
-->
<html>
    <head>
        <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<style>
        .fa {  
  color: red;
}  
.nav-link{
    color: #b518a3;
}
.az{
            background-color: black;
            color: white;
        }
         .first{
            margin-bottom: -1px;
            background: 0 0;
            border-top-left-radius: 0.25rem;
            border-top-right-radius: 0.25rem;
            text-decoration: none;
            width: 20px;
            height: 30px;
            display: flex;
            flex-wrap: wrap;
            align-content: center;
            
        }
    .click:hover{
        color: green;
    }
        </style>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Rescue</title>
    
    </head>
    <body>
        <div class="container-fluid" style="background-color: #4aed05;">
         <div class="row nav nav-tabs" style="color: #f2440a;font-size: 20px; font-weight: bold;" id="qwe" '>
                <div class="col-sm-1">
                    <img src="logo/logo_7.0.jpg" height="65px" width="65px">
                </div>
             <div class="col-sm-6" style="font-size: 40px; font-weight: bold; color: #fa1d05;" >
                   SAMRAS BHARAT SEVA SANSTHAN
                </div>
                <div class="col-sm-1 nav-item">
                    <a class="first click" href="HOME.php">&nbsp; HOME</a>
                </div><!-- comment --> 
                <div class="col-sm-1 nav-item dropdown">
                     <a class="first click"  href="Work.php" >&nbsp; WORK</a>
                </div><!-- comment -->
                <div class="col-sm-1 nav-item">
                    <a class="first click" href="Report-issue.php">&nbsp; REPORT</a>
                </div><!-- comment -->
                <div class="col-sm-1 nav-item">
                    <a class="first click" href="Contact-us.php">&nbsp; CONTACT</a>
                </div>
                <div class="col-sm-1 nav-item">
                    <a class="first click" href="FAQ.php">&nbsp;&nbsp;&nbsp;<BR>About us</a>
                </div><!-- comment -->
            </div>
        </div>       
        <h1 style="text-align:center;"> <i><u>Social Activities : </u></i></h1><br>
         <div class="container-fluid" align="center">
         <div class="row nav nav-tabs">
             <div class="col-sm-1"></div>
             <div class="col-sm-10" style="font-size:24px">
                 People are forgetting our culture and tradition, to bring them
                 into practice and maintain attachment to them, Samras India works
                 to maintain cultural and traditional values by organizing many social
                 activities like Dahi Handi Competition, Celebrating Navratra Sthapna.
                 <br>
                 <br>
                 <h3 style="text-align:left;  color: #48434a"> <i><u>1. Gokulam 2022</u></i></h3><br>
             Fourth Gokulam Dahi Handi Competition was organized on the day of Bhadav Shukla Paksha Ashtami. 
             In this, both boys and girls categories  were kept, in which the categories were subdivided
             of 8-12 years, 12-18 years and 18+ years are included. Every team of each category that broke
             the pot was rewarded prize money and certificate. Along with this, Bal Gopal competition and
             Jhaki of Lord Shri Krishna were also decorated. A total of 34 teams participated in this
             program and many children also came as Bal Gopal. This program was successful with the
             help of the volunteers and people of society.
             </div>
             <div class="col-sm-1"></div>
         </div></div><!-- comment -->
            <br><br> 
    <div class="container-fluid" align="center">
         <div class="row nav nav-tabs" style="color: #1c2a94;" id="qwe" '>
             <div class="col-sm-1"></div>
             <div class="col-sm-10">
                 <marquee direction="right" 
        behavior="alternate" 
        >
    <img src="rescue1/2.jpeg" width="450px" height="300px" alt="alt"/>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <img src="rescue1/3.jpeg" width="450px" height="300px" alt="alt"/>
        
    </marquee>
             </div>
                 <div class="col-sm-1"></div>
             </div><!-- comment -->
         </div>
    </div><br>
        <div class="container-fluid" align="center">
         <div class="row nav nav-tabs">
             <div class="col-sm-1"></div>
             <div class="col-sm-10" style="font-size:24px">
                
                
                 <br>
                 <h3 style="text-align:left;  color: #48434a"> <i><u>1. Save Cow Campaign </u></i></h3><br>
             Today the whole of India is suffering from the epidemic of Cow Mat Lumpi Virus.
             At this time the cows is very sad due to no special arrangement by the government
             and the society is also in a duty-bound state.
             In such a situation, Samras Bharat has said that we will help the cows to fight
             the epidemic, under this, Our teams  provide medicines and spray medicinal spray
             to the nomadic cows to help them grow their immunity and disease fighting ability.
             <br>
             </div>
             <div class="col-sm-1"></div>
         </div></div><!-- comment -->
         <br><br>
    <div class="container-fluid" align="center">
         <div class="row nav nav-tabs" style="color: #1c2a94;" id="qwe" '>
             <div class="col-sm-1"></div>
             <div class="col-sm-10">
                 <marquee direction="right" 
        behavior="alternate" 
        >
    <img src="rescue1/2.jpeg" width="450px" height="300px" alt="alt"/>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <img src="rescue1/3.jpeg" width="450px" height="300px" alt="alt"/>
        
    </marquee>
             </div>
                 <div class="col-sm-1"></div>
             </div><!-- comment -->
         </div>
    </div><br>


 <br>
         <div align="center" class="az">
            <br><h3>Created by XVL</h3>
            <h4>Copyright &COPY; All Rights Reserved</h4>
        </div>
        <?php
        // put your code here
        ?>
    </body>
</html>
