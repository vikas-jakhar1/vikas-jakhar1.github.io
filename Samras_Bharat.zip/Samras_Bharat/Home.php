<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHPWebPage.php to edit this template
-->
<html>
    <head>
        <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<style>
        .fa {  
  color: red;
}  
.nav-link{
    color: #b518a3;
}
.az{
            background-color: black;
            color: white;
        }
        .qqaz{
            background-color: white;
            color: purple;
        }
        .first{
            margin-bottom: -1px;
            background: 0 0;
            border-top-left-radius: 0.25rem;
            border-top-right-radius: 0.25rem;
            text-decoration: none;
            width: 20px;
            height: 30px;
            display: flex;
            flex-wrap: wrap;
            align-content: center;
            
        }
    .click:hover{
        color: green;
    }
    table.my-table {
        border: solid thin;
        border-collapse: separate;
        border-spacing: 0px;
        border-color: black;
        margin-left: auto;
        margin-right: auto;
        margin-top: 10px;
        font-size: 14px;
    }
    
            table.my-table tbody th {
                background: rgb(28, 58, 112);
                background: rgba(28, 58, 112, 1);
                color: rgb(255,255,255);
                color: rgba(255,255,255,1);
            }
    
            table.my-table tbody tr:nth-child(even) {
                background: rgb(255, 255, 255);
                background: rgba(255, 255, 255, .8);
            }
    
            table.my-table tbody tr:nth-child(odd) {
                background: rgb(239, 239, 239);
                background: rgba(239, 239, 239, .8);
            }
    
            table.my-table tbody td {
                background: rgb(255, 255, 255);
                background: rgba(255, 255, 255, 1);
                color: rgb(0, 0, 0);
                color: rgba(0, 0, 0, 1);
            }
            .slider{
    margin: auto;
    position:relative;
    width: 300px;
    height: 300px;
    transform-style: preserve-3d;
    animation: rotate 30s linear infinite;
    
}

@keyframes rotate{
    0%{
        transform: perspective(1000px) rotateY(0deg);
    }

    100%{
        transform: perspective(1000px) rotateY(360deg);
    }
}

.slider span{
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    transform-origin: center;
    transform-style: preserve-3d;
    transform: rotateY(calc(var(--i)*45deg)) translateZ(350px);
}

.slider span img{
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    border-radius: 100px;
    object-fit: cover;
    transition: 2s;

}

.slider span:hover img{
transform: translateY(-50px) scale(1.2);
}
        </style>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Home</title>
    
    </head>
    <body >
        <div class="container-fluid" style="background-color: #4aed05;">
         <div class="row nav nav-tabs" style="color: #f2440a;font-size: 20px; font-weight: bold;" id="qwe" '>
                <div class="col-sm-1">
                    <img src="logo/logo_7.0.jpg" height="65px" width="65px">
                </div>
             <div class="col-sm-6" style="font-size: 40px; font-weight: bold; color: #fa1d05;" >
                   SAMRAS BHARAT SEVA SANSTHAN
                </div>
                <div class="col-sm-1 nav-item">
                    <a class="first click" href="HOME.php">&nbsp; HOME</a>
                </div><!-- comment --> 
                <div class="col-sm-1 nav-item dropdown">
                     <a class="first click"  href="Work.php" >&nbsp; WORK</a>
                </div><!-- comment -->
                <div class="col-sm-1 nav-item">
                    <a class="first click" href="Report-issue.php">&nbsp; REPORT</a>
                </div><!-- comment -->
                <div class="col-sm-1 nav-item">
                    <a class="first click" href="Contact-us.php">&nbsp; CONTACT</a>
                </div>
                <div class="col-sm-1 nav-item">
                    <a class="first click" href="FAQ.php">&nbsp;&nbsp;&nbsp;<BR>About us</a>
                </div><!-- comment -->
            </div>
        </div>    
 

        
         
            
         
        </div>
        
        <div class="container-fluid" align="center">
         <div class="row nav nav-tabs" style="color: #1c2a94;" id="qwe" '>
             
             <div class="col-sm-6">
                 <br><br><br>
                 <h2>
                     Samras Bharat seva Sansthan registered as  <br>non-governmental-organization<br> in the global movements to end child <br>exploitation
Founded in 2020
Liberates<br> and rehabilitate vulnerable and exploited children<br> and prosecutes those responsible for the atrocities.
                 </h2>
                 <br><br><br>
             </div>
             <div class="col-sm-6">
                 <img src="logo/imgg.jpeg" style="width:700px;height:400px">
             </div>
         </div>
             
        </div>
			
        	
        <div class="container-fluid" align="center">
         <div class="row nav nav-tabs" style="color: #1c2a94;" id="qwe" '>
             <div class="col-sm-1">
             </div>
             <div class="col-sm-4">
                 <br><br>
                 
          <h3 style="color: #3b313a;"> MISSION</h3>
        
        <p><h4>We identify, release, rehabilitate and educate children in servitude through prevention, direct intervention, coalition-building, mass mobilisation and legal action to create a child-friendly society.</p>
        </h4></div>
              <div class="col-sm-1">
             </div>
             <div class="col-sm-1">
             </div>
             <div class="col-sm-4">
                 <br><br>
        
         <h3 style="color: #3b313a;">VISION </h3>
        
        
        <p><h4>SBSS seeks to create a child-friendly world where all children are free from exploitation and abuse.</h4></p>
             </div>
              <div class="col-sm-1">
             </div>
         </div>
            
             <div class="row nav nav-tabs" style="color: #1c2a94;" id="qwe" '>
             
             <div class="col-sm-12">
                   <br>
        
         <h3 style="color: #3b313a">OUR VALUES </h3>
        
    
           
           <p><h3>Justice, Courage, Compassion, Integrity and Freedom.</h3></p>
        </div>
             </div>
        </div> 
                <table class="my-table" cellpadding="2px"  border="3" align="center">
                    <tr align="center">
                        <th><br>
                            <h3>&nbsp;&nbsp;&nbsp;&nbsp; Total Rescue: 553 &nbsp;&nbsp;&nbsp;&nbsp;</h3>
                        </th><!-- comment -->
                        <th><br>
                            <h3>&nbsp;&nbsp;&nbsp;&nbsp; F.I.R. : 104 &nbsp;&nbsp;&nbsp;&nbsp;</h3>
                        </th>   
                    </tr>
                    <tr align="center">
                        <th><br>
                            <h3>&nbsp;&nbsp;&nbsp;&nbsp; Accuse Arrested: 142 &nbsp;&nbsp;&nbsp;&nbsp;</h3><br>
                        </th><!-- comment -->
                        <th><br>
                            <h3>&nbsp;&nbsp;&nbsp;&nbsp; Convention : 1 &nbsp;&nbsp;&nbsp;&nbsp;</h3><br>
                        </th>
                    </tr>
                </table>
             
        <br><br>
        <br >
        <br>
        <br>
        <br >
        <br>
        <br>
        <div class="slider">
                <span style="--i:1;"><img src="rescue1/1.jpeg" alt=""></span>
                <span style="--i:2;"><img src="rescue1/2.jpeg" alt=""></span>
                <span style="--i:3;"><img src="rescue1/3.jpeg" alt=""></span>
                <span style="--i:4;"><img src="rescue1/4.jpeg" alt=""></span>
                <span style="--i:5;"><img src="rescue1/5.jpeg" alt=""></span>
                <span style="--i:6;"><img src="rescue1/6.jpeg" alt=""></span>
                <span style="--i:7;"><img src="rescue1/3.jpeg" alt=""></span>
                <span style="--i:8;"><img src="rescue1/4.jpeg" alt=""></span>
                
        </div>
        <br >
        <br>
        <br>
        <br >
        <br>
        <br>
           
         <div align="center" class="az">
            <br><h3>Created by XVL</h3>
            <h4>Copyright &COPY; All Rights Reserved</h4>
        </div>
        <?php
        // put your code here
        ?>
    </body>
</html>