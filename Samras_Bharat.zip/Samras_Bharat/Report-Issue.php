<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHPWebPage.php to edit this template
-->
<html>
    <head>
        <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<style>
        .fa {  
  color: red;
}  
 .fa {  
  color: red;
}  
.nav-link{
    color: #b518a3;
}
.az{
            background-color: black;
            color: white;
        }
         .first{
            margin-bottom: -1px;
            background: 0 0;
            border-top-left-radius: 0.25rem;
            border-top-right-radius: 0.25rem;
            text-decoration: none;
            width: 20px;
            height: 30px;
            display: flex;
            flex-wrap: wrap;
            align-content: center;
            
        }
    .click:hover{
        color: green;
    }
        
     
        .pag{
           flex-shrink: 0;
           max-width: 100%;
           padding-right: 1.5rem;
           padding-left: 1.5rem;
           margin-top: 1.5rem;
    
        }
       
         .column {
                float: left;
                 width: 25%;
        }
        form{
            margin-left: 20%;
        }

        .row:after {
             content: "";
             display: table;
            clear: both;
  
  
            }
                .form-control {
                
                display: block;
                width: 70%;
                height: 34px;
                padding: 6px 12px;
                font-size: 14px;
                line-height: 1.42857143;
                color: #555;
                background-color: #fff;
                background-image: none;
                border: 1px solid #d6d6d6;
                -webkit-transition: border-color ease-in-out .15s, -webkit-box-shadow ease-in-out .15s;
                -o-transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;
                transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s
            }
        </style>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Report</title>
    
    </head>
    <body>
       <div class="container-fluid" style="background-color: #4aed05;">
         <div class="row nav nav-tabs" style="color: #f2440a;font-size: 20px; font-weight: bold;" id="qwe" '>
                <div class="col-sm-1">
                    <img src="logo/logo_7.0.jpg" height="65px" width="65px">
                </div>
             <div class="col-sm-6" style="font-size: 40px; font-weight: bold; color: #fa1d05;" >
                   SAMRAS BHARAT SEVA SANSTHAN
                </div>
                <div class="col-sm-1 nav-item">
                    <a class="first click" href="HOME.php">&nbsp; HOME</a>
                </div><!-- comment --> 
                <div class="col-sm-1 nav-item dropdown">
                     <a class="first click"  href="Work.php" >&nbsp; WORK</a>
                </div><!-- comment -->
                <div class="col-sm-1 nav-item">
                    <a class="first click" href="Report-issue.php">&nbsp; REPORT</a>
                </div><!-- comment -->
                <div class="col-sm-1 nav-item">
                    <a class="first click" href="Contact-us.php">&nbsp; CONTACT</a>
                </div>
                <div class="col-sm-1 nav-item">
                   <a class="first click" href="FAQ.php">&nbsp;&nbsp;&nbsp;<BR>About us</a>
                </div><!-- comment -->
            </div>
        </div>    
           <h1 style="text-align:center ;">Report A Case</h1>
           <form action="" method="post" enctype="multipart/form-data"  >
                <div class="pag">
                    <label for="ChildName"></label>
                <div class="column" id="ChildName">
                    <label>Child Name<input type="text" name="ChildName" class="form-control" required/></label>
                </div>
                <label for="MobileNo"></label>
                <div class="column" id="MobileNo">
                    <label>Mobile No.<input type="text"  name="Mobile" class="form-control" /></label>
                
                </div>
                <br />
                <label for="Gender"></label>
                <div class="column" id="Gender">
                    <label>Gender :</label>
                <label><input type="radio" value="male" name="Gender">Male</label>
                <label><input type="radio" value="male" name="Gender">Female</label>
                <label><input type="radio" value="male" name="Gender">other</label>
                </div>
                </div>
                <br />
                <br />
                <div class="pag">
                    <label for="age"></label>
                <div class="column" id="age">
                    <label>Age<input type="number" name="age"  class="form-control" min="0"/></label>
                
                </div>
                <label for="Address"></label>
                <div class="column" id="Address">
                <label >Address<input type="text"  name="Address" class="form-control" required/></label>
                
                </div>
                <label for="City"></label>
                <div class="column" id="City">
                <label >City<input type="text"  name="City" class="form-control" required/></label>
                
                </div>
                </div>
                <br />
                <br />
                <div class="pag">
                    <label for="State"></label>
                <div class="column" id="State">
                <label >State<input type="text"  name="State" class="form-control" required/></label>
                
                </div>
                <label for="Pincode"></label>
                <div class="column" id="Pincode">
                <label>Pincode<input type="number" name="Pincode" class="form-control" min="0" required/></label>
                
                </div>
                <label for="Language"></label>
                <div class="column" id="Language">
                <label>Language Spoken<input type="text"  name="LanguageSpoken" class="form-control" /></label>
                
                </div>
                </div>
                <br />
                <br />
                <div >
                <label for="text">Reason For Reporting</label> 
                <textarea rows="8" id="text" name="Reason" style="height: 100px;" class="form-control"  required></textarea>   
                </div>                                                                         
                
                <br />
        <br />
        <br />
        <div>
        <p>If reporting on behalf of child please share your name and mobile number <br />
        (Your Information will be kept confidential and will be used only to locate the child)</p>
        <br />
        </div>
        <div class="pag">
                <label for="name1"></label>
                <div class="column" id="name1">
                <label >Full Name<input type="text" name="name1" class="form-control" required/></label>
                
                </div>
                <label for="Mobile1"></label>
                <div class="column" id="Mobile1">
                <label>Mobile No.<input type="number"  name="mobile1" class="form-control" required/></label>
                
                </div>
                <label for="Relation"></label>
                <div class="column" id="Relation">
                <label for="Relation">Relation<input type="text" name="Relation"  class="form-control" required></label>
                
                </div>
             </div>
                <br /> 
                <br />
            <div>
                <input type="reset" name="reset" />
                <input type="submit" name="submit" value="Submit"/>
            </div>
                <br><!-- comment -->
                <br><!-- comment -->
                
    </form>
        <div align="center" class="az">
            <br><h3>Created by XVL</h3>
            <h4>Copyright &COPY; All Rights Reserved</h4>
        </div>
        <?php
        // put your code here
        ?>
    </body>
</html>